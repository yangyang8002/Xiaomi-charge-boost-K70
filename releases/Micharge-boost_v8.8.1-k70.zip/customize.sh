SKIPUNZIP=0
# 部分系统（ColorOS 移植等）上 mkdir("/") 返回 EINVAL，busybox/toybox 的 mkdir -p 会从 / 开始逐级创建而直接失败：改为跳过已存在的目录、只创建缺的那级
mkdir(){ if [ "$1" = -p ]; then shift; _r=0; for _d in "$@"; do case $_d in /*) _p=;; *) _p=.;; esac; _o=$IFS; IFS=/; set -f; for _c in $_d; do [ -z "$_c" ] && continue; _p=$_p/$_c; [ -d "$_p" ] || command mkdir "$_p" || { _r=1; break; }; done; set +f; IFS=$_o; done; return $_r; else command mkdir "$@"; fi; }
# 机型识别（v8.5.9 起不做机型校验，只识别型号；v8.7.1 起校验处理器型号，非适配处理器退出安装；内核只识别）：已适配机型用表内参数，其它机型按通用参数安装
# 移植系统 product 属性可能被改，优先认 vendor/odm 底包属性和 /vendor/build.prop（sysinfo.sh 同逻辑）
MCB_ROOT=$MODPATH; . $MODPATH/models.sh
CODE=$(detect_code)
case "$CODE" in ""|unknown) CODE=$(getprop ro.product.vendor.device); CODE=${CODE:-$(getprop ro.product.device)}; CODE=${CODE:-unknown};; esac
model_load "$CODE"
# v8.7.1：先校验品牌（非小米红米退出），再识别处理器型号，非适配处理器（含天玑、玄戒）直接退出安装；内核版本只识别显示
KV=$(uname -r 2>/dev/null)
if ! BRD=$(brand_check "$CODE"); then
  ui_print "********************"; ui_print " 小米/红米充电加速模块"; ui_print "********************"
  ui_print "! 非小米 / 红米机型：品牌 $BRD（$(getprop ro.product.model)）"
  ui_print "! 本模块只适配小米、红米手机"
  ui_print "! 底包识别：代号 ${CODE:-未知}，底包 $(sh $MODPATH/sysinfo.sh 2>/dev/null | sed -n 4p | grep . || echo 未识别)"
  abort "! 已退出安装，模块未刷入"
fi
if ! PCR=$(platform_check "$SOC"); then
  ui_print "********************"; ui_print " 小米/红米充电加速模块"; ui_print "********************"
  ui_print "! 非适配机型：处理器 $PCR，内核 ${KV:-未知}"
  ui_print "! 本模块只适配骁龙 SM8550 / SM8650 / SM8750 / SM8850 / SM8950 / SM8975"
  abort "! 已退出安装，模块未刷入"
fi
# v8.8.0：8550 / 8650（红米K70 vermeer、红米K70 Pro manet 等）还没有已收录的原厂 dtbo 模板，
# 只能通用模式安装：dtbo 逐项比对全部已收录模板，只写原厂值吻合的项，比对不到就不改 dtbo。
# TL=1 时后面各步 dtbo 菜单默认选「不修改」，保证第一次刷入一定能装上模块本体
TL=0; tpl_soc "$SOC" || TL=1
if [ $TL = 1 ]; then
  ui_print "- 处理器 SM$SOC 暂无已收录原厂 dtbo 模板：通用模式"
  ui_print "  dtbo 逐项比对，只写原厂值吻合的项；比对不到就保持本机原厂（不会乱写）"
  ui_print "  想完整适配可先跑 tools/k70-probe.sh 取原厂 dtbo，见 tools/k70-probe-readme.md"
fi
# 按机型写模块名与机型代号（运行时脚本、WebUI 读 $MODPATH/model）
echo $CODE > $MODPATH/model
sed -i "s|^name=.*|name=$MODNAME|" $MODPATH/module.prop
D=/data/adb/mi_charge_boost
mkdir -p $D/sessions
# 从旧 ID（mi_charge_monitor）迁移：接管 dtbo 原版备份和写入状态，
# 防止以后卸载充电监控时把本模块写入的 dtbo 还原掉
O=/data/adb/mi_charge_monitor
if [ -d $O/dtbo ]; then
  mkdir -p $D/dtbo; cp -an $O/dtbo/. $D/dtbo/ 2>/dev/null
  rm -f $O/dtbo/state_a $O/dtbo/state_b $O/dtbo/state
fi
for f in interval shutdown_mv; do [ -f $O/$f ] && [ ! -f $D/$f ] && cp $O/$f $D/$f; done
[ -d $O/sessions ] && [ -z "$(ls $D/sessions 2>/dev/null)" ] && { cp -a $O/sessions/. $D/sessions/ 2>/dev/null; [ -f $O/index.csv ] && cp $O/index.csv $D/; }
rm -f $D/detail.list $D/ps.cache
getkey(){
  # 返回 up / down / none（15 秒无操作）
  t=0
  while [ $t -lt 15 ]; do
    ev=$(timeout 1 getevent -lqc 1 2>/dev/null)
    case "$ev" in
      *KEY_VOLUMEUP*DOWN*) echo up; return;;
      *KEY_VOLUMEDOWN*DOWN*) echo down; return;;
    esac
    t=$((t+1))
  done
  echo none
}
# 输出记录：KernelSU / APatch 安装页支持清屏指令，选择时整页重绘，
# 光标直接在选项上移动，不追加多余行；Magisk 等不支持时退回逐行追加
# 清屏重绘时连同 KernelSU 自己输出的开头一起补回（Logo、模块大小、安装路径等）
LOG=""
if [ "$KSU" = true ] && [ "$APATCH" != true ]; then
  SZ=$(unzip -l "$ZIPFILE" 2>/dev/null | tail -1 | awk '{printf "%.2f MB", $1/1000000}')
  SL=${SLOT:-$(getprop ro.boot.slot_suffix)}
  NM=$(grep_prop name $MODPATH/module.prop 2>/dev/null); [ -n "$NM" ] || NM=$MODNAME
  AU=$(grep_prop author $MODPATH/module.prop 2>/dev/null); [ -n "$AU" ] || AU=酷安@鱼楠
  LOG=$(cat <<'EOF'
 _  __                    _ ____  _   _
| |/ /___ _ __ _ __   ___| / ___|| | | |
| ' // _ \ '__| '_ \ / _ \ \___ \| | | |
| . \  __/ |  | | | |  __/ |___) | |_| |
|_|\_\___|_|  |_| |_|\___|_|____/ \___/
EOF
)
  # 星号长度照 KernelSU 的 print_title：取两行字节数较大者 + 2
  bar(){ a=$(printf '%s' "$1" | wc -c); b=$(printf '%s' "$2" | wc -c); [ $a -gt $b ] && b=$a; printf "%$((b+2))s" | tr ' ' '*'; }
  B1=$(bar "$NM" "by $AU"); B2=$(bar "Powered by KernelSU" "")
  LOG="$LOG

- Module size: $SZ
- Installing to $MODPATH
- Extracting module files
- Running module installer
- Current boot slot: $SL
- Device is system-as-root
$B1
 $NM
 by $AU
$B1
$B2
 Powered by KernelSU
$B2
- Extracting module files
"
fi
out(){ ui_print "$1"; LOG="$LOG$1
"; }
REDRAW=0; { [ "$KSU" = true ] || [ "$APATCH" = true ]; } && REDRAW=1
CLR=$(printf '\033[H\033[J')
draw(){ # 重绘：已有内容 + 当前菜单（$1 = 当前项，$2 = 标记）
  ui_print "$CLR"
  printf '%s' "$LOG" | while IFS= read -r l; do ui_print "$l"; done
  i=1; for o in $OPTS; do o=$(echo "$o" | tr '\037' ' ')
    if [ $i = $1 ]; then ui_print "  $2 $i. $o"; else ui_print "     $i. $o"; fi; i=$((i+1)); done
}
# menu <步骤> <标题> <说明> <选项...>：音量+ 切换，音量- 确认，15 秒无操作选当前项（默认第一项）
menu(){
  st=$1; tt=$2; ds=$3; shift 3; n=$#; idx=1
  OPTS=""; for o in "$@"; do OPTS="$OPTS $(echo "$o" | tr ' ' '\037')"; done
  out " "; out "【第 $st 步】$tt"; [ -n "$ds" ] && out "  $ds"
  if [ $REDRAW = 1 ]; then
    draw 1 "▶"
    while true; do
      case "$(getkey)" in
        up) idx=$((idx+1)); [ $idx -gt $n ] && idx=1; draw $idx "▶";;
        *) break;;
      esac
      sleep 0.2
    done
    i=1; for o in "$@"; do LOG="$LOG     $i. $o
"; i=$((i+1)); done
    eval "cur=\$$idx"; OPTS=""; draw 0 ""; out "  ✔ 已选：$cur"
  else
    i=1; for o in "$@"; do ui_print "   $i. $o"; i=$((i+1)); done
    eval "cur=\$$idx"; ui_print "  ▶ 当前：$idx. $cur"
    while true; do
      case "$(getkey)" in
        up) idx=$((idx+1)); [ $idx -gt $n ] && idx=1; eval "cur=\$$idx"; ui_print "  ▶ 当前：$idx. $cur";;
        *) break;;
      esac
      sleep 0.2
    done
    ui_print "  ✔ 已选：$cur"
  fi
  SEL=$idx
}
out "********************"
out " $MODNAME  by 酷安@鱼楠"
out "********************"
{ read -r SI_N; read -r SI_D; read -r SI_O; read -r SI_B; } <<EOF
$(sh $MODPATH/sysinfo.sh)
EOF
out "- 设备: $SI_N ($SI_D)　系统: $SI_O${SI_B:+（底包 $SI_B）}"
out "- 处理器: $PCR　内核: ${KV:-未知}"
out "- 音量+ 切换　音量- 确认　15 秒不操作选默认"
IS_DADA=0; [ "$CODE" = dada ] && IS_DADA=1
[ "$SI_D" = "$CODE" ] || out "- 机型代号按底包属性识别为 $CODE（$MN）"
[ "$GEN" = 1 ] && out "- 非已适配机型（$(model_names) 之外）：通用安装，dtbo 逐项比对原厂值，只写吻合的项，FFC 截止电压保持本机原厂"
DI=-; DT=-; DV=-; DZ=-
fa(){ echo "$(($1/1000)).$(($1%1000/100))A" | sed 's/\.0A$/A/'; }
if [ $TL = 1 ]; then
  # 没有原厂模板的处理器（8550/8650）：默认不改 dtbo，先保证模块本体装得上；仍允许手动尝试
  menu 1 "dtbo 快充电流" "SM$SOC 暂无原厂 dtbo 模板，逐项比对不一定有吻合项，失败会退出安装" "不修改电流（推荐）" "仍要尝试写入 $(fa $MX)（模块上限）"
  [ $SEL = 2 ] && DI=$MX
elif [ "$GEN" = 1 ]; then
  menu 1 "dtbo 快充电流" "只改与已适配机型原厂值逐项吻合的满速温区，其余保持本机原厂" "修改为 $(fa $MI)" "修改为 $(fa $MX)（模块上限）" "不修改电流"
  case $SEL in 1) DI=$MI;; 2) DI=$MX;; esac
elif [ $IS_DADA = 1 ]; then
  menu 1 "dtbo 快充电流" "修改后全温段以该电流满速" "修改为 15.5A" "修改为 20.5A（90W 理论极限）" "不修改电流"
  case $SEL in 1) DI=15500;; 2) DI=20500;; esac
else
  # 其它机型：只把原厂满速温区（及降速温区，若改了温度）的电流改成所选值，低温段保持原厂
  menu 1 "dtbo 快充电流" "修改后满速温区以该电流满速（原厂 $(fa $MI)）" "修改为 $(fa $MI)（原厂值）" "修改为 $(fa $MX)（模块上限）" "不修改电流"
  case $SEL in 1) DI=$MI;; 2) DI=$MX;; esac
fi
if [ $TL = 1 ]; then
  menu 2 "dtbo 满速/断充温度" "没有原厂模板时同样不建议改，和电流一起写入" "不修改温度（推荐）" "修改为 55°C"
  [ $SEL = 2 ] && DT=55
else
  menu 2 "dtbo 满速/断充温度" "设定温度以下满速，超过停充" "修改为 55°C" "不修改温度"
  [ $SEL = 1 ] && DT=55
fi
# 关机电压只给 2800mV 一档（用户 2026-10-21 要求；v8.6.4 恢复 8.6.3 方案）
V0T="原厂 ${V0}mV"; [ "${GEN:-0}" = 1 ] && V0T="原厂值以本机为准"
if [ $TL = 1 ]; then
  menu 3 "dtbo 内核关机电压" "电池电压降到该值才关机（$V0T）" "不修改关机电压（推荐）" "修改为 2800mV"
  [ $SEL = 2 ] && DV=2800
else
  menu 3 "dtbo 内核关机电压" "电池电压降到该值才关机（$V0T）" "修改为 2800mV" "不修改关机电压"
  [ $SEL = 1 ] && DV=2800
fi
if [ "$HZ" = 1 ]; then
  menu 4 "屏幕超频" "华星屏添加 132/144/155/165Hz 刷新率档位" "屏幕超频 165Hz" "不超频屏幕"
  [ $SEL = 1 ] && DZ=165
  S4=5
else
  S4=4
fi
menu $S4 "低电量延迟关机" "电量锁定 2%、关闭 30 秒关机提示，电压降到设定值再关机" "启用低电量延迟关机" "不启用低电量延迟关机"
if [ $SEL = 1 ]; then MV=${V0:-3000}; [ "$DV" != - ] && MV=$DV; else MV=0; fi
echo $MV > $D/shutdown_mv
menu $((S4+1)) "公版 PPS 解锁" "内置 FreePPS（Seyud，GPL-3.0）：第三方 PPS 头放行高功率快充，小米原装头照常走私有协议" "关闭" "开启"
PPS=0; [ $SEL = 2 ] && PPS=1; echo $PPS > $D/pps
menu $((S4+2)) "充电监测软件" "配合${MODNAME}使用的充电监测 App（充电监测 v5.9，含公版 PPS 控制中心磁贴）" "安装充电检测软件" "不安装"
CM=$SEL
DR=0; DO=$D/dtbo.out; true > $DO 2>/dev/null || { DO=/dev/mcb_dtbo.out; true > $DO; }
if [ "$DI$DT$DV$DZ" != "----" ]; then
  chmod 755 $MODPATH/dtbo/dtbopatch $MODPATH/dtbo/dtbopatch.bin $MODPATH/dtbo/dtbofv $MODPATH/dtbo/dtbofv.bin $MODPATH/dtbo/dtbomulti
  sh $MODPATH/dtbo/apply.sh $DI $DV $DT $DZ > $DO 2>&1; DR=$?
  grep -q "^! " $DO && DR=1
fi
ui_print " "
ui_print "======== 确认结果 ========"
if [ "$DI$DT$DV$DZ" != "----" ]; then
  if [ $DR = 0 ]; then ui_print "✅ dtbo 刷入成功，重启生效"
  elif grep -q '回滚失败' $DO; then ui_print "❌ dtbo 写入失败且回滚失败，分区内容不确定"; ui_print "   请勿重启，先手动刷回原厂 dtbo"
  else ui_print "❌ dtbo 刷入失败"; ui_print "   原因: $(grep '^! ' $DO | tail -1 | sed 's/^! //')"; fi
fi
f(){ [ "$1" = - ] && echo 不修改 || echo "$1$2"; }
if true; then
  ui_print "- 快充电流: $(f $DI mA)　断充温度: $(f $DT °C)　关机电压: $(f $DV mV)"
  if [ $IS_DADA = 1 ]; then [ "$DZ" = 165 ] && ui_print "- 屏幕: 超频 165Hz" || ui_print "- 屏幕: 不超频"; fi
  if [ "$DI$DT$DV$DZ" != "----" ]; then
    ui_print "- dtbo 写入过程:"; grep -v "^ERROR: bad vbmeta" $DO | while read -r l; do ui_print "  $l"; done
  else
    ui_print "- dtbo 不修改"
  fi
fi
# v8.7.2：dtbo 刷入失败直接退出安装（模块不刷入、充电监测软件也不装）；全部选「不修改」不算失败
if [ "$DI$DT$DV$DZ" != "----" ] && [ $DR != 0 ]; then
  ui_print " "
  ui_print "! dtbo 刷入失败，已退出安装：模块未刷入，充电监测软件未安装"
  grep -q '回滚失败' $DO && ui_print "! 回滚失败，分区内容不确定：请勿重启，先手动刷回原厂 dtbo"
  abort "! 请把上面的 dtbo 写入过程截图反馈"
fi
[ $MV -gt 0 ] && ui_print "- 低电量延迟关机: 启用（${MV}mV，WebUI 可调）" || ui_print "- 低电量延迟关机: 不启用"
if [ $PPS = 1 ]; then
  if [ -d /data/adb/modules/FreePPS ] && [ ! -f /data/adb/modules/FreePPS/disable ]; then ui_print "- 公版 PPS 解锁: 开启，但已安装 FreePPS，本模块此项自动停用"
  else ui_print "- 公版 PPS 解锁: 开启（内置 FreePPS v1.7.0，重启后生效）"; fi
else ui_print "- 公版 PPS 解锁: 关闭"; fi
if [ "$CM" = 1 ]; then
  A=$MODPATH/apk/charge_monitor.apk; T=/data/local/tmp/charge_monitor.apk
  inst(){ cd / && { cp $A $T 2>/dev/null && chmod 644 $T && pm install -r -g $T 2>&1; } || cat $A | pm install -r -g -S $(stat -c %s $A) 2>&1; }
  r=$(inst)
  case "$r" in *UPDATE_INCOMPATIBLE*|*SIGNATURES*) pm uninstall com.yunan.chargehub >/dev/null 2>&1; r=$(inst); ui_print "- 充电监测软件签名不同，已卸载旧版后重装";; esac; rm -f $T
  case "$r" in *Success*) ui_print "- 充电监测软件: 已安装";; *) touch $D/cm_pending; ui_print "- 充电监测软件: 现在装不上（$r），重启后自动安装";; esac
else ui_print "- 充电监测软件: 不安装"; fi
[ -f $D/cm_pending ] && { mkdir -p $D/apk; cp -f $MODPATH/apk/charge_monitor.apk $D/apk/; }
rm -rf $MODPATH/apk
# 高刷切换：接管旧的独立高刷切换模块（配置、日志迁移过来，旧模块重启后移除）——只有小米15
if [ $IS_DADA = 1 ]; then
OH=/data/adb/modules/xiaomi15_hz_switch
[ -f /data/adb/xiaomi15_hz_switch.conf ] && [ ! -f $D/hz.conf ] && cp /data/adb/xiaomi15_hz_switch.conf $D/hz.conf
[ -f /data/adb/xiaomi15_hz_switch.history ] && [ ! -f $D/hz.history ] && cp /data/adb/xiaomi15_hz_switch.history $D/hz.history
if [ -d $OH ]; then touch $OH/remove; ui_print "- 已合并独立的「高刷切换」模块，旧模块重启后自动移除"; fi
ui_print "- 高刷切换: WebUI 底部「高刷切换」页点选 120/132/144/156/165Hz"
fi
set_perm_recursive $MODPATH 0 0 0755 0755
ui_print "- 充电记录只在充电时写入，放电不记录"
ui_print "- 重启后生效；不想重启可在 WebUI 设置里点启动"
ui_print "- 致谢：酷安@低线阻狂魔、酷安@花橋桥（PPS 节点）"
ui_print "        内置 FreePPS v1.7.0（Seyud / 酷安@瓦力喀，GPL-3.0，见 pps/README-FreePPS.txt）"
ui_print "        酷安@久保Sama / 刷新率APP（高刷切换思路）"
sh $MODPATH/dtbo/apply.sh desc >/dev/null 2>&1
[ "$DR" != 0 ] && sed -i "s|^description=|description=❌ DTBO 刷入失败（$(grep "^! " $D/dtbo.out | tail -1 | sed "s/^! //")） ｜ |" $MODPATH/module.prop
